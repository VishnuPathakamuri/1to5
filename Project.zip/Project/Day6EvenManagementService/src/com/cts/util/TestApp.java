package com.cts.util;

import java.io.StringReader;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.apache.avro.data.Json;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestApp {

	public static void main(String[] args) {
		ClientConfig clientConfig = new DefaultClientConfig();
		Client client=Client.create(clientConfig);
		WebResource service = client.resource("http://localhost:7070/Day6EvenManagementService/");
		ClientResponse cresponse = 
				service.path("rest").path("/ImageService/GetData/32;eventName=Training")
				.type("text/plain")
			    .get(ClientResponse.class); 
		System.out.println(cresponse.getCookies()); 
		System.out.println(cresponse); 
	}
}
