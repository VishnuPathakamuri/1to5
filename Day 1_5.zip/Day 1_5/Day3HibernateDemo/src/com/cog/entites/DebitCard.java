package com.cog.entites;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="DebitCard")
//@DiscriminatorValue(value="DebitCardObj")
public class DebitCard extends Payment{
	
	@Column(name="DebitCardNo")
	private long debitCardNo;
	
	@Column(name="Dvv")
	private int dvv;
	
	@Column(name="DebitCardName")
	private String debitCardName;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DExpiryDate")
	private  Date dExpiryDate;
	
	
	
	
	public long getDebitCardNo() {
		return debitCardNo;
	}
	public void setDebitCardNo(long debitCardNo) {
		this.debitCardNo = debitCardNo;
	}
	public int getDvv() {
		return dvv;
	}
	public void setDvv(int dvv) {
		this.dvv = dvv;
	}
	public String getDebitCardName() {
		return debitCardName;
	}
	public void setDebitCardName(String debitCardName) {
		this.debitCardName = debitCardName;
	}
	public Date getdExpiryDate() {
		return dExpiryDate;
	}
	public void setdExpiryDate(Date dExpiryDate) {
		this.dExpiryDate = dExpiryDate;
	}
	

	
	
	
	
}
