package com.cog.entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CTSPerson")
@Inheritance(strategy=InheritanceType.JOINED)
public class Person {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="AdhaarNo")
	private int adhaarNo;
	
	@Column(name="Name")
	private String pName;
	
	@OneToOne
	@JoinColumn(name="Address")
	private Address address;

	public int getAdhaarNo() {
		return adhaarNo;
	}

	public void setAdhaarNo(int adhaarNo) {
		this.adhaarNo = adhaarNo;
	}

	
	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	

}
