package com.cog.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entites.Address;
import com.cog.entites.Manager;
import com.cog.entites.Person;

public class PersonTest {
   private DaoManager dm;
   
	

	@Before
	public void setUp() throws Exception {
		dm=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	/*@Test
	public void test1() {
		//fail("Not yet implemented");
		//Person p=new Person();
		Manager m=new Manager();
		//p.setpName("ghbjbj");
		m.setLeaveApproval(true);
		m.setNoOfProjects(2);
		m.setLocation("fhyuhfyu");
		m.setpName("fhsyufh");
		m.setProject("fydgh");
	    Address a=new Address();
	    a.setCity("fdhf");
	    a.setState("hjghs");
	    a.setStreetName("gffgyuyhey");
	   assertTrue( dm.AddPerson(m,a));
		
	}*/
	
	@Test
	public void test() {
		for (Manager manager : dm.GetAll()) {
			System.out.println(manager.getAdhaarNo()+"\t");
			System.out.println(manager.getLocation()+"\t");
			System.out.println(manager.getNoOfProjects()+"\t");
			System.out.println(manager.getpName()+"\t");
			System.out.println(manager.getAddress().getStreetName()+"\t");
			System.out.println(manager.getAddress().getCity()+"\t");
			System.out.println(manager.getAddress().getState()+"\t");
			System.out.println(manager.getProject() +"\t");
			//System.out.println(manager.get);
		}
	
	
	
	
	
	
	
	
	

}}
