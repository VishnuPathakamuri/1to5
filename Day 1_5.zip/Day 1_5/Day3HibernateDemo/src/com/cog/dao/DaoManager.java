
package com.cog.dao;

import java.util.List;

import javax.persistence.criteria.From;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entites.Address;
import com.cog.entites.Employee;
import com.cog.entites.Manager;
import com.cog.entites.Payment;
import com.cog.entites.Person;
import com.cog.utilities.HibernateUtil;

public class DaoManager {
	
	private SessionFactory sf;
	private Session ses;
	private boolean status;
	
	public DaoManager(){
		sf=HibernateUtil.Getfactory();
	}
	
	public boolean AddPayment(Payment payment){
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			ses.save(payment);
			ses.getTransaction().commit();
		status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		ses.close();
		return status;
	}
	
	
	public boolean AddPerson(Person person,Address address){
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			//ses.persist(man);
			ses.persist(address);
			//ses.persist(emp);
			
			person.setAddress(address);
			ses.persist(person);
			ses.getTransaction().commit();
		status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		ses.close();
		return status;
	}
	
	public List<Manager> GetAll(){
		ses=sf.openSession();
		return ses.createQuery("from CTSManager").list();
	}
	

}
