package com.cts.test;

import java.util.Iterator;

import com.cts.dao.BookingDao;
import com.cts.entity.Location;

public class TestApp {

	public static void main(String[] args) {
		BookingDao bd=new BookingDao();
		//Location location=(Location) bd.GetLocationByName("cts99");
		//System.out.println(bd.GetLocation());
		//System.out.println(bd.GetMaxLocationId());
		
		
		/*for (Location location:bd.SortLocation()) {
			System.out.println(location.getLocationName());*/
		
		/*for (Location location:bd.DscLocation()) {
			System.out.println(location.getLocationName());}*/
		//System.out.println(bd.GetMaxSecondLocationId());
		
		//System.out.println(location.getLocationName());
			
		for (Location location1 :bd.GetLocationByName("CTS")) {
			System.out.println(location1.getLocationName());
			
		}	
		
		
		
	}
	
	
	
	
	
	
	
	
}
