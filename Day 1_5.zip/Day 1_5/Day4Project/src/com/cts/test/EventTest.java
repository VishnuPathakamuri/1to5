package com.cts.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cts.dao.BookingDao;
import com.cts.entity.Location;

public class EventTest {

	private BookingDao bkd;
	@Before
	public void setUp() throws Exception {
		
		bkd=new BookingDao();
	}

	@After
	public void tearDown() throws Exception {
	}


	public void test1() {
		//fail("Not yet implemented");
		Location loct=new Location();
		loct.setLocationName("asv suntech park");
		assertTrue(bkd.InsertLocation(loct)>0);
		
	}
	
	public void test2() {
		//fail("Not yet implemented");
		
		assertTrue(bkd.insertLocation());
		
	}

	
	
	
	public void test3() {
		//fail("Not yet implemented");
		
		Assert.assertNotNull(bkd.GetLocationByName("CTS1"));
		
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		
		Assert.assertTrue(bkd.TestSeconLevelCache());
		
	}
	
	
	
	
	
}
