package com.cts.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Booking")

public class Booking {
	
	@EmbeddedId
	
	/*@AttributeOverrides({
		@AttributeOverride(name="CTS_Event_Id",column=@Column(name="CTS_Event_Id")),
		@AttributeOverride(name="CTS_Cust_Id",column=@Column(name="CTS_Cust_Id"))
	})*/
	
	private BookingC bookingC;
	
	@Column(name="Amount")
	private int amount;
	
	@Column(name="Ticket_Booked")
	private int ticketBooked;

	
	public BookingC getBookingC() {
		return bookingC;
	}

	public void setBookingC(BookingC bookingC) {
		this.bookingC = bookingC;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTicketBooked() {
		return ticketBooked;
	}

	public void setTicketBooked(int ticketBooked) {
		this.ticketBooked = ticketBooked;
	}
	
	

}
