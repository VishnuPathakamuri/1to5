package com.cog.test;

import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entities.Location;
import com.cog.utility.HibernateUtil;

public class TestApp {
	public static void main(String[] args) {
		SessionFactory sf=HibernateUtil.getSessionFactory();
		Session ses= sf.openSession();
		ses.beginTransaction();
		try{
			
			Location location=new Location();
			location.setLocationName(" vishnu ");
			ses.save(location);
			ses.getTransaction().commit();
			
			
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
			
		}
		
		
		/*System.out.println("retrieve from first level cache.....");
		Location ctsmessage= (Location) ses.load(Location.class, 3);
		//System.out.println(ctsmessage.getDescription());
		System.out.println("Before Clear"+ses.contains(ctsmessage));
		ses.evict(ctsmessage);
		System.out.println("After Clear"+ses.contains(ctsmessage));
		System.out.println("retrieve from second level cache.....");
		Cache cache = sf.getCache();
		System.out.println(cache.containsEntity(Location.class, 3));
		ctsmessage=(Location) ses.load(Location.class, 3);
		//System.out.println(ctsmessage.getDescription());
		System.out.println(ctsmessage.getLocationName());*/
		
		
		
		
		
		
		
		/*Location location=(Location) ses.load(Location.class, 2);
		System.out.println("check first level cache");
		System.out.println("Status of Object"+ses.contains(location));
		ses.evict(location);
		System.out.println("check first level  cache after evict");
		System.out.println("Status of Object"+ses.contains(location));
		Cache cache=sf.getCache();
		System.out.println("check second level  cache after evict");
		System.out.println("Status of Object"+cache.containsEntity(Location.class, 2));
		System.out.println("check second level  cache after evict");
		location=(Location) ses.load(Location.class, 2);
		System.out.println(location.getLocationName());*/
		
		
		
		
		
		
		
		
		
		
		ses.close();
	}
	

}
