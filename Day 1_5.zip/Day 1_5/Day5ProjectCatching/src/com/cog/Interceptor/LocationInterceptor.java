package com.cog.Interceptor;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.Type;

import com.cog.entities.Location;
import com.cog.entities.LocationTracker;
import com.cog.utility.HibernateUtil;

public class LocationInterceptor extends EmptyInterceptor{
	private boolean isActivity;
	private String message;
	

	@Override
	public int[] findDirty(Object entity, Serializable id,
			Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		System.out.println("findDirty");
		return super.findDirty(entity, id, currentState, previousState, propertyNames,
				types);
	}

	@Override
	public void onDelete(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		System.out.println("onDelete");
		super.onDelete(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onFlushDirty(Object entity, Serializable id,
			Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		System.out.println("onFlushDirty");
		return super.onFlushDirty(entity, id, currentState, previousState,
				propertyNames, types);
	}

	@Override
	public boolean onLoad(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		System.out.println("onLoad");
		return super.onLoad(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		System.out.println("onSave");
		if(entity instanceof Location){
			Location loc=(Location) entity;
			isActivity=true;
			message="Insert"+entity;
			return isActivity;
		}
		else
		
		return isActivity;
		
		//return super.onSave(entity, id, state, propertyNames, types);
	}

	@Override
	public void postFlush(Iterator entities) {
		System.out.println("postFlush");
		System.out.println(isActivity);
		if(isActivity){
			
			SessionFactory sf=HibernateUtil.getSessionFactory();
			Session ses=sf.openSession();
			ses.beginTransaction();
			LocationTracker lt=new LocationTracker();
			lt.settActivity(message);
			lt.setActivityDate(new Date());
			ses.save(lt);
			isActivity=false;
			ses.getTransaction().commit();
			ses.close();
		}
		super.postFlush(entities);
	}

	@Override
	public void preFlush(Iterator entities) {
		System.out.println("preFlush");
		super.preFlush(entities);
	}

	
	
	
}
