package com.cog.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="Location_Tracker")
public class LocationTracker {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="TrackerId")
	private int trackerId;
	
	
	@Column(name="tActivity")
    private String tActivity;
	
	@Temporal(TemporalType.DATE)
	@Column(name="ActivityDate")
    private Date activityDate;
	
	

	public int getTrackerId() {
		return trackerId;
	}

	public void setTrackerId(int trackerId) {
		this.trackerId = trackerId;
	}

	public String gettActivity() {
		return tActivity;
	}

	public void settActivity(String tActivity) {
		this.tActivity = tActivity;
	}

	public Date getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(Date activityDate) {
		this.activityDate = activityDate;
	}
    
	
	
	
}
