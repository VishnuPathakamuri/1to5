package com.cognizant.dao;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Event;
import com.cognizant.utilities.HibernateUtil;


public class EventManager {

	private SessionFactory factory;
	private Session session;
	public EventManager(){
		factory=HibernateUtil.Getfactory();
	}
		public boolean AddEvent(Event event){
		boolean status= false;
		session =factory.openSession();
		session.beginTransaction();
	
		try{
			session.save(event);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e){
			session.getTransaction().rollback();
		}
		return status;
			
		}
	}

