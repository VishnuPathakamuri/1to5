package com.cognizant.utilities;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	

	public  static SessionFactory Getfactory(){
		return new Configuration().configure("com/cognizant/resourses/hibernate.cfg.xml").buildSessionFactory();
		
	}

}
