package com.cognizant.entities;

public class Room {
	private Integer roomNo;
	private String  location;
    private int capacity;
    private boolean sys_ava;
    
    public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isSys_ava() {
		return sys_ava;
	}
	public void setSys_ava(boolean sys_ava) {
		this.sys_ava = sys_ava;
	}
	public boolean isProj_ava() {
		return proj_ava;
	}
	public void setProj_ava(boolean proj_ava) {
		this.proj_ava = proj_ava;
	}
	private boolean proj_ava;
	
}
