package com.cognizant.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="Event")
public class Event {
   @EmbeddedId
    private EventKey ek;
	
	@Column(name="Duration")
	private int duration;
	
	@Column(name="Location")
	private String location;
	
	@Column(name="EventName")
	private String eventName;
	
	
	
	public EventKey getEk() {
		return ek;
	}
	public void setEk(EventKey ek) {
		this.ek = ek;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	
}
