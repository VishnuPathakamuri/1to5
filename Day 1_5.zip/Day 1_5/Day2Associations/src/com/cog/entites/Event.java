package com.cog.entites;

public class Event {

}
