package com.cts.dao;

import java.util.List;

import net.sf.ehcache.Status;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.entities.Customer;
import com.cts.resources.HibernateUtil;

public class CustomerManager {
	private static SessionFactory sf;
	private static Session ses;
	private static boolean status;
	
	
	public static boolean AddCustomer(Customer customer){
		
		sf=HibernateUtil.Getfactory();
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			ses.save(customer);
			ses.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		ses.close();
		return status;
	}

	public static List<Customer> getAll(){
		sf=HibernateUtil.Getfactory();
		ses=sf.openSession();
		return ses.createQuery("from Customer").list();
	}
		
	
	
	
	
	
	
	
	
}
